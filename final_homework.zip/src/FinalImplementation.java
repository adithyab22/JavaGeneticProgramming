
public class FinalImplementation {
public static void main(String[] args) {
	Console.run(new SymbRegGUI(), 600, 600);
}
}
